﻿namespace YawsCups
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BudapestBranch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.PecsBranch = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // BudapestBranch
            // 
            this.BudapestBranch.BackColor = System.Drawing.Color.White;
            this.BudapestBranch.Font = new System.Drawing.Font("Modern No. 20", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BudapestBranch.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BudapestBranch.Location = new System.Drawing.Point(187, 107);
            this.BudapestBranch.Name = "BudapestBranch";
            this.BudapestBranch.Size = new System.Drawing.Size(231, 80);
            this.BudapestBranch.TabIndex = 0;
            this.BudapestBranch.Text = "Budapest";
            this.BudapestBranch.UseVisualStyleBackColor = false;
            this.BudapestBranch.Click += new System.EventHandler(this.BudapestBranch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(389, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(384, 123);
            this.label1.TabIndex = 2;
            this.label1.Text = "Yaw's Cups";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // PecsBranch
            // 
            this.PecsBranch.BackColor = System.Drawing.Color.White;
            this.PecsBranch.Font = new System.Drawing.Font("Modern No. 20", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PecsBranch.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.PecsBranch.Location = new System.Drawing.Point(187, 255);
            this.PecsBranch.Name = "PecsBranch";
            this.PecsBranch.Size = new System.Drawing.Size(231, 80);
            this.PecsBranch.TabIndex = 3;
            this.PecsBranch.Text = "Pecs";
            this.PecsBranch.UseVisualStyleBackColor = false;
            this.PecsBranch.Click += new System.EventHandler(this.PecsBranch_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.PecsBranch);
            this.panel1.Controls.Add(this.BudapestBranch);
            this.panel1.Location = new System.Drawing.Point(27, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(601, 438);
            this.panel1.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Maroon;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1184, 127);
            this.panel2.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Maroon;
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Location = new System.Drawing.Point(259, 224);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(650, 493);
            this.panel3.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1182, 808);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BudapestBranch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button PecsBranch;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
    }
}

