﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YawsCups
{
    public class singleton
    {
        public List<int> Id { get; set; }
        public double TotalPrice = .0;
        public double EsspressoCost = .0;
        public double FilteredCost = .0;
        public double FrapCost = .0;
        public List<double> Price { get; set; }
        public Dictionary<string, string> BudapestAdmins;
        public Dictionary<string, string> PecsAdmins;
        public Dictionary<string , bool> BudapestBeveragesTypes;
        public Dictionary<string, bool> PecsBeveragesTypes;

        public static singleton _instance;
        public static singleton Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new singleton();
                    // once the insatce is created all the intial object will be creates with it 
                    _instance.CreateInstance();

                }

                return _instance;
            }
        }

        public void CreateInstance()
        {
            Id = new List<int>();
            Price = new List<double>();
            BudapestAdmins = new Dictionary<string, string>();
            PecsAdmins = new Dictionary<string, string>();
            BudapestAdmins.Add("zeyna", "123");
            BudapestAdmins.Add("harry", "code0");
            BudapestAdmins.Add("gyapong", "6742");
            PecsAdmins.Add("Ahmad", "123");
            PecsAdmins.Add("helena", "1234");
            PecsAdmins.Add("yaw", "123456");
            BudapestBeveragesTypes = new Dictionary<string, bool>();
            PecsBeveragesTypes = new Dictionary<string, bool>();
            BudapestBeveragesTypes.Add("Esspresso", false);
            BudapestBeveragesTypes.Add("Americano", false);
            BudapestBeveragesTypes.Add("Cappuccino", false);
            BudapestBeveragesTypes.Add("Caffe", false);
            BudapestBeveragesTypes.Add("White Chocolate", false);
            BudapestBeveragesTypes.Add("Filtered Coffee", false);
            BudapestBeveragesTypes.Add("Brew", false);
            BudapestBeveragesTypes.Add("Misto", false);
            BudapestBeveragesTypes.Add("Frappuccino", false);
            BudapestBeveragesTypes.Add("Chocolate Frap", false);
            BudapestBeveragesTypes.Add("Strawberry Frap", false);
            BudapestBeveragesTypes.Add("Vanilla Frap", false);

            //Pecs beverages
            PecsBeveragesTypes.Add("Esspresso", false);
            PecsBeveragesTypes.Add("Americano", false);
            PecsBeveragesTypes.Add("Cappuccino", false);
            PecsBeveragesTypes.Add("Caffe", false);
            PecsBeveragesTypes.Add("White Chocolate", false);
            PecsBeveragesTypes.Add("Filtered Coffee", false);
            PecsBeveragesTypes.Add("Brew", false);
            PecsBeveragesTypes.Add("Misto", false);
            PecsBeveragesTypes.Add("Frappuccino", false);
            PecsBeveragesTypes.Add("Chocolate Frap", false);
            PecsBeveragesTypes.Add("Strawberry Frap", false);
            PecsBeveragesTypes.Add("Vanilla Frap", false);









        }
    }
}
