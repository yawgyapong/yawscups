﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YawsCups
{
    abstract class Sube
    {

        public List<Esspresso> EsspressoType { get; set; }
        public List<FilteredCoffee> FilteredCoffeeType { get; set; }
        public List<Frappuccino> FrappuccinoType { get; set; }
        public abstract List<Esspresso> EsspressoTypes();
        public abstract List<FilteredCoffee> FilteredCoffeeTypes();
        public abstract List<Frappuccino> FrappuccinoTypes();
        public List<Coffee> RaisedCoffee = new List<Coffee>();
        public abstract void RegisterRaisedCoffee(List<Coffee> coffee);
        public void TemplateMethod(string AddedBeverage,string DeletedBeverage,double raise)
        {
            AddBeverage(AddedBeverage);
            DeleteBeverage(DeletedBeverage);
            update(raise);

        }
        public abstract void AddBeverage(string beverage);
        public abstract void DeleteBeverage(string beverage);
        public void update(double raise)
        {

            foreach (Coffee c in RaisedCoffee)
            {
                if(c.GetType() == typeof(Esspresso))
                {
                    singleton.Instance.EsspressoCost = raise;

                }
                if (c.GetType() == typeof(FilteredCoffee))
                {
                    singleton.Instance.FilteredCost = raise;

                }
                if (c.GetType() == typeof(Frappuccino))
                {
                    singleton.Instance.FrapCost = raise;

                }
                
            }
        }
        
    }
    class PecsLocation : Sube
    {
        public PecsLocation()
        {
            EsspressoType = EsspressoTypes();
            FilteredCoffeeType = FilteredCoffeeTypes();
            FrappuccinoType = FrappuccinoTypes();
        }
        public override List<Esspresso> EsspressoTypes()
        { 
            List<Esspresso> esspresso = new List<Esspresso>() { (new Esspresso()), (new Americano()), (new Cappuccino()), (new Caffe()), (new WhiteChocolate()), };
            foreach (var o in esspresso)
            {
                singleton.Instance.PecsBeveragesTypes[o.ToString()] = true;
            }
            return esspresso;
        }

        public override List<FilteredCoffee> FilteredCoffeeTypes()
        {
            List<FilteredCoffee> filteredCoffee = new List<FilteredCoffee>() { (new FilteredCoffee()), (new Brew()), (new Misto()), };
            foreach (var o in filteredCoffee)
            {
                singleton.Instance.PecsBeveragesTypes[o.ToString()] = true;
            }
            return filteredCoffee;
        }

        public override List<Frappuccino> FrappuccinoTypes()
        {
            List<Frappuccino> frappuccino = new List<Frappuccino>() { (new Frappuccino()), (new VanillaFrap()), (new ChocolateFrap()), (new StrawberryFrap()), };
            foreach (var o in frappuccino)
            {
                singleton.Instance.PecsBeveragesTypes[o.ToString()] = true;
            }
            return frappuccino;
        }

        public override void AddBeverage(string beverage)
        {
           
                switch (beverage)
                {
                    case "Esspresso":
                        singleton.Instance.PecsBeveragesTypes["Esspresso"] = true;
                        EsspressoType.Add(new Esspresso());
                        break;
                    case "Americano":
                        singleton.Instance.PecsBeveragesTypes["Americano"] = true;
                        EsspressoType.Add(new Americano());
                        break;
                    case "Caffe":
                        singleton.Instance.PecsBeveragesTypes["Caffe"] = true;
                        EsspressoType.Add(new Caffe());
                        break;
                    case "Cappuccino":
                        singleton.Instance.PecsBeveragesTypes["Cappuccino"] = true;
                        EsspressoType.Add(new Cappuccino());
                        break;
                    case "Filtered Coffee":
                        singleton.Instance.PecsBeveragesTypes["Filtered Coffee"] = true;
                        FilteredCoffeeType.Add(new FilteredCoffee());
                        break;
                    case "Misto":
                        singleton.Instance.PecsBeveragesTypes["Misto"] = true;
                        FilteredCoffeeType.Add(new Misto());
                        break;
                    case "Brew":
                        singleton.Instance.PecsBeveragesTypes["Brew"] = true;
                        FilteredCoffeeType.Add(new Brew());
                        break;
                    case "Frappuccino":
                        singleton.Instance.PecsBeveragesTypes["Frappuccino"] = true;
                        FrappuccinoType.Add(new Frappuccino());
                        break;
                    case "Chocolate Frap":
                        singleton.Instance.PecsBeveragesTypes["Chocolate Frap"] = true;
                        FrappuccinoType.Add(new ChocolateFrap());
                        break;
                    case "Strawberry Frap":
                        singleton.Instance.PecsBeveragesTypes["Chocolate Frap"] = true;
                        FrappuccinoType.Add(new StrawberryFrap());
                        break;
                    case "Vanilla Frap":
                        singleton.Instance.PecsBeveragesTypes["Chocolate Frap"] = true;
                        FrappuccinoType.Add(new VanillaFrap());
                        break;

                    default:
                        break;
                }
                
            
            
        }

        public override void DeleteBeverage(string beverage)
        {
            switch (beverage)
            {
                case "Esspresso":
                    singleton.Instance.PecsBeveragesTypes["Esspresso"] = false;
                    EsspressoType.RemoveAll(x => x.GetType() == typeof(Esspresso));
                    break;
                case "Americano":
                    singleton.Instance.PecsBeveragesTypes["Americano"] = false;
                    EsspressoType.RemoveAll(x => x.GetType() == typeof(Americano));
                    break;
                case "Caffe":
                    singleton.Instance.PecsBeveragesTypes["Caffe"] = false;
                    EsspressoType.RemoveAll(x => x.GetType() == typeof(Caffe));
                    break;
                case "Cappuccino":
                    singleton.Instance.PecsBeveragesTypes["Cappuccino"] = false;
                    EsspressoType.RemoveAll(x => x.GetType() == typeof(Cappuccino));
                    break;
                case "Filtered Coffee":
                    singleton.Instance.PecsBeveragesTypes["Filtered Coffee"] = false;
                    FilteredCoffeeType.RemoveAll(x => x.GetType() == typeof(FilteredCoffee));
                    break;
                case "Misto":
                    singleton.Instance.PecsBeveragesTypes["Misto"] = false;
                    FilteredCoffeeType.RemoveAll(x => x.GetType() == typeof(Misto));
                    break;
                case "Brew":
                    singleton.Instance.PecsBeveragesTypes["Brew"] = false;
                    FilteredCoffeeType.RemoveAll(x => x.GetType() == typeof(Brew));
                    break;
                case "Frappuccino":
                    singleton.Instance.PecsBeveragesTypes["Frappuccino"] = false;
                    FrappuccinoType.RemoveAll(x => x.GetType() == typeof(Frappuccino));
                    break;
                case "Chocolate Frap":
                    singleton.Instance.PecsBeveragesTypes["Chocolate Frap"] = false;
                    FrappuccinoType.RemoveAll(x => x.GetType() == typeof(ChocolateFrap));
                    break;
                case "Strawberry Frap":
                    singleton.Instance.PecsBeveragesTypes["Strawberry Frap"] = false;
                    FrappuccinoType.RemoveAll(x => x.GetType() == typeof(StrawberryFrap));
                    break;
                case "Vanilla Frap":
                    singleton.Instance.PecsBeveragesTypes["Vanilla Frap"] = false;
                    FrappuccinoType.RemoveAll(x => x.GetType() == typeof(VanillaFrap));
                    break;

                default:
                    break;
            }
            
        }

        public override void RegisterRaisedCoffee(List<Coffee> coffee)
        {
            RaisedCoffee.AddRange(coffee);
        }
    }
    class BudapestBranch : Sube
    {
        public BudapestBranch()
        {
            EsspressoType = EsspressoTypes();
            FilteredCoffeeType = FilteredCoffeeTypes();
            FrappuccinoType = FrappuccinoTypes();
        }     
        
        public override List<Esspresso> EsspressoTypes()
        {
            List<Esspresso> esspresso = new List<Esspresso>() { (new Esspresso()), (new Americano()),  };
            foreach (var o in esspresso)
            {
                singleton.Instance.BudapestBeveragesTypes[o.ToString()] = true;
            }
            return esspresso;
        }

        public override List<FilteredCoffee> FilteredCoffeeTypes()
        {
            List<FilteredCoffee> filteredCoffee = new List<FilteredCoffee>() { (new FilteredCoffee()), };
            foreach (var o in filteredCoffee)
            {
                singleton.Instance.BudapestBeveragesTypes[o.ToString()] = true;
            }
            return filteredCoffee;
        }

        public override List<Frappuccino> FrappuccinoTypes()
        {
            List<Frappuccino> frappuccino = new List<Frappuccino>() { (new Frappuccino()), (new ChocolateFrap()), };
            foreach (var o in frappuccino)
            {
                singleton.Instance.BudapestBeveragesTypes[o.ToString()] = true;
            }
            return frappuccino;
        }




        public override void AddBeverage(string beverage)
        {

            switch (beverage)
            {
                case "Esspresso":
                    singleton.Instance.BudapestBeveragesTypes["Esspresso"] = true;
                    EsspressoType.Add(new Esspresso());
                    break;
                case "Americano":
                    singleton.Instance.BudapestBeveragesTypes["Americano"] = true;
                    EsspressoType.Add(new Americano());
                    break;
                case "Caffe":
                    singleton.Instance.BudapestBeveragesTypes["Caffe"] = true;
                    EsspressoType.Add(new Caffe());
                    break;
                case "Cappuccino":
                    singleton.Instance.BudapestBeveragesTypes["Cappuccino"] = true;
                    EsspressoType.Add(new Cappuccino());
                    break;
                case "Filtered Coffee":
                    singleton.Instance.BudapestBeveragesTypes["Filtered Coffee"] = true;
                    FilteredCoffeeType.Add(new FilteredCoffee());
                    break;
                case "Misto":
                    singleton.Instance.BudapestBeveragesTypes["Misto"] = true;
                    FilteredCoffeeType.Add(new Misto());
                    break;
                case "Brew":
                    singleton.Instance.BudapestBeveragesTypes["Brew"] = true;
                    FilteredCoffeeType.Add(new Brew());
                    break;
                case "Frappuccino":
                    singleton.Instance.BudapestBeveragesTypes["Frappuccino"] = true;
                    FrappuccinoType.Add(new Frappuccino());
                    break;
                case "Chocolate Frap":
                    singleton.Instance.BudapestBeveragesTypes["Chocolate Frap"] = true;
                    FrappuccinoType.Add(new ChocolateFrap());
                    break;
                case "Strawberry Frap":
                    singleton.Instance.BudapestBeveragesTypes["Chocolate Frap"] = true;
                    FrappuccinoType.Add(new StrawberryFrap());
                    break;
                case "Vanilla Frap":
                    singleton.Instance.BudapestBeveragesTypes["Chocolate Frap"] = true;
                    FrappuccinoType.Add(new VanillaFrap());
                    break;

                default:
                    break;
            }

        }

        public override void DeleteBeverage(string beverage)
        {
            switch (beverage)
            {
                case "Esspresso":
                    singleton.Instance.BudapestBeveragesTypes["Esspresso"] = false;
                    Esspresso esspresso = new Esspresso();
                    EsspressoType.RemoveAll(x => x.GetType() == typeof(Esspresso));
                    break;
                case "Americano":
                    singleton.Instance.BudapestBeveragesTypes["Americano"] = false;
                    EsspressoType.RemoveAll(x => x.GetType() == typeof(Americano));
                    break;
                case "Caffe":
                    singleton.Instance.BudapestBeveragesTypes["Caffe"] = false;
                    EsspressoType.RemoveAll(x => x.GetType() == typeof(Caffe));
                    break;
                case "Cappuccino":
                    singleton.Instance.BudapestBeveragesTypes["Cappuccino"] = false;
                    EsspressoType.RemoveAll(x => x.GetType() == typeof(Cappuccino));
                    break;
                case "Filtered Coffee":
                    singleton.Instance.BudapestBeveragesTypes["Filtered Coffee"] = false;
                    FilteredCoffeeType.RemoveAll(x => x.GetType() == typeof(FilteredCoffee));
                    break;
                case "Misto":
                    singleton.Instance.BudapestBeveragesTypes["Misto"] = false;
                    FilteredCoffeeType.RemoveAll(x => x.GetType() == typeof(Misto));
                    break;
                case "Brew":
                    singleton.Instance.BudapestBeveragesTypes["Brew"] = false;
                    FilteredCoffeeType.RemoveAll(x => x.GetType() == typeof(Brew));
                    break;
                case "Frappuccino":
                    singleton.Instance.BudapestBeveragesTypes["Frappuccino"] = false;
                    FrappuccinoType.RemoveAll(x => x.GetType() == typeof(Frappuccino));
                    break;
                case "Chocolate Frap":
                    singleton.Instance.BudapestBeveragesTypes["Chocolate Frap"] = false;
                    FrappuccinoType.RemoveAll(x => x.GetType() == typeof(ChocolateFrap));
                    break;
                case "Strawberry Frap":
                    singleton.Instance.BudapestBeveragesTypes["Strawberry Frap"] = false;
                    FrappuccinoType.RemoveAll(x => x.GetType() == typeof(StrawberryFrap));
                    break;
                case "Vanilla Frap":
                    singleton.Instance.BudapestBeveragesTypes["Vanilla Frap"] = false;
                    FrappuccinoType.RemoveAll(x => x.GetType() == typeof(VanillaFrap));
                    break;

                default:
                    break;
            }

        }


        public override void RegisterRaisedCoffee(List<Coffee> coffee)
        {
            RaisedCoffee.AddRange(coffee);
        }
    }
}
