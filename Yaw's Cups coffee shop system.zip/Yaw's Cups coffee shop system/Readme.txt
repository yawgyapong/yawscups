Yaw's Cups COFFEE SHOP SYSTEM IN C#

For the Pecs Branch, you can test login with the following credentials
username = yaw
password = 123456

If you select the Budapest Branch, you can test login with the following credentials
username = gyapong
password = 6742


Scrumboard link:
https://trello.com/b/qjYwthUq/yaws-cupscoffee-shop






 